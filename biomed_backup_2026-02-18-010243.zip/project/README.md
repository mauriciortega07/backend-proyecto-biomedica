<h3>Backend de Interfaz Biomedica</h3>
      <a href="https://github.com/mauriciortega07/backend-proyecto-biomedica.git">Repository</a>
      </br>
      <ul>
        <li>Backend service, which responds to all requests and calls made from Biomedical Interface.</li>
        <li>Biomedical Backend Service include equipment records, and can be edited and deleted.</li>
        <li>CRUD operations management.</li>
        <li>Use of JS, Express Framework and MySql.</li>
        <li>It is currently adapted for use in Railway App servie.</li>
      </ul>
